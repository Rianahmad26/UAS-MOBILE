package com.example.resepmasakan;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    private TextView txtTitle, txtInstructions;
    private ImageView imgRecipe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        txtTitle = findViewById(R.id.txtTitle);
        txtInstructions = findViewById(R.id.txtInstructions);
        imgRecipe = findViewById(R.id.imgRecipe);

        // Get data from Intent
        String title = getIntent().getStringExtra("title");
        String instructions = getIntent().getStringExtra("instructions");
        String imageUrl = getIntent().getStringExtra("imageUrl");

        txtTitle.setText(title);
        txtInstructions.setText(instructions);
        Glide.with(this).load(imageUrl).into(imgRecipe);
    }
}
