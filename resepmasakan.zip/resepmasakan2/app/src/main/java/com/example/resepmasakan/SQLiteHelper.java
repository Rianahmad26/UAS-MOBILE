package com.example.resepmasakan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "ResepDB";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "resep";
    public static final String COLUMN_ID = "idMeal";
    public static final String COLUMN_NAME = "strMeal";
    public static final String COLUMN_THUMB = "strMealThumb";
    public static final String COLUMN_INSTRUCTIONS = "strInstructions";

    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " TEXT PRIMARY KEY, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_THUMB + " TEXT, " +
                COLUMN_INSTRUCTIONS + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Method to insert or update recipe data into SQLite database.
     */
    public void insertOrUpdateRecipe(String idMeal, String strMeal, String strMealThumb, String strInstructions) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Insert data using ContentValues to prevent SQL injection and improve readability
        ContentValues values = new ContentValues();
        values.put(COLUMN_ID, idMeal);
        values.put(COLUMN_NAME, strMeal);
        values.put(COLUMN_THUMB, strMealThumb);
        values.put(COLUMN_INSTRUCTIONS, strInstructions);

        // Use INSERT OR REPLACE to update existing data with the same idMeal
        db.insertWithOnConflict(TABLE_NAME, null, values, SQLiteDatabase.CONFLICT_REPLACE);
    }

    /**
     * Method to retrieve all recipes stored in the database.
     */
    public Cursor getAllRecipes() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null, null, null, null);
    }

    /**
     * Method to check if a recipe exists by its idMeal.
     */
    public boolean isRecipeExist(String idMeal) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, COLUMN_ID + " = ?", new String[]{idMeal}, null, null, null);
        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    /**
     * Method to delete all recipes from the database (useful for clearing data when needed).
     */
    public void deleteAllRecipes() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
    }
}
