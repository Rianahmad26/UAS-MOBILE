package com.example.resepmasakan;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ResepAdapter adapter;
    private ArrayList<ModelResep> resepList = new ArrayList<>();
    private SQLiteHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new SQLiteHelper(this);

        // Load offline data from SQLite
        loadOfflineData();

        // If there is no data, fetch from API
        if (resepList.isEmpty()) {
            fetchDataFromAPI();
        } else {
            // If offline data exists, set it to the adapter
            adapter = new ResepAdapter(resepList, MainActivity.this);
            recyclerView.setAdapter(adapter);
        }
    }

    /**
     * Load data from SQLite database (offline).
     */
    private void loadOfflineData() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(SQLiteHelper.TABLE_NAME, null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex(SQLiteHelper.COLUMN_ID);
                int nameIndex = cursor.getColumnIndex(SQLiteHelper.COLUMN_NAME);
                int thumbIndex = cursor.getColumnIndex(SQLiteHelper.COLUMN_THUMB);
                int instructionsIndex = cursor.getColumnIndex(SQLiteHelper.COLUMN_INSTRUCTIONS);

                if (idIndex != -1 && nameIndex != -1 && thumbIndex != -1 && instructionsIndex != -1) {
                    String idMeal = cursor.getString(idIndex);
                    String strMeal = cursor.getString(nameIndex);
                    String strThumb = cursor.getString(thumbIndex);
                    String strInstructions = cursor.getString(instructionsIndex);

                    resepList.add(new ModelResep(idMeal, strMeal, strThumb, strInstructions));
                } else {
                    Log.e("MainActivity", "Column not found in database");
                }
            } while (cursor.moveToNext());
            cursor.close();
        }
    }

    /**
     * Fetch data from API and update database and RecyclerView.
     */
    private void fetchDataFromAPI() {
        String url = "https://www.themealdb.com/api/json/v1/1/search.php?s=";
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        JSONArray meals = response.getJSONArray("meals");

                        // Clear existing data before inserting new data
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        db.execSQL("DELETE FROM " + SQLiteHelper.TABLE_NAME);

                        for (int i = 0; i < meals.length(); i++) {
                            JSONObject meal = meals.getJSONObject(i);
                            String idMeal = meal.getString("idMeal");
                            String strMeal = meal.getString("strMeal");
                            String strMealThumb = meal.getString("strMealThumb");
                            String strInstructions = meal.getString("strInstructions");

                            // Using ContentValues to insert data securely
                            ContentValues values = new ContentValues();
                            values.put(SQLiteHelper.COLUMN_ID, idMeal);
                            values.put(SQLiteHelper.COLUMN_NAME, strMeal);
                            values.put(SQLiteHelper.COLUMN_THUMB, strMealThumb);
                            values.put(SQLiteHelper.COLUMN_INSTRUCTIONS, strInstructions);

                            // Insert data into database
                            db.insert(SQLiteHelper.TABLE_NAME, null, values);

                            // Add the recipe to the list
                            resepList.add(new ModelResep(idMeal, strMeal, strMealThumb, strInstructions));
                        }

                        // Set the adapter for RecyclerView after fetching data
                        adapter = new ResepAdapter(resepList, MainActivity.this);
                        recyclerView.setAdapter(adapter);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    // Handle error in case the API request fails
                    Toast.makeText(MainActivity.this, "Failed to fetch data from API", Toast.LENGTH_SHORT).show();
                });

        // Add the request to the Volley queue
        queue.add(request);
    }
}
