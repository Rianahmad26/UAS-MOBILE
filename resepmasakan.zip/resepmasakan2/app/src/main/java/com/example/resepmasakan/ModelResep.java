package com.example.resepmasakan;

public class ModelResep {
    private String idMeal;
    private String strMeal;
    private String strMealThumb;
    private String strInstructions;

    // Constructor
    public ModelResep(String idMeal, String strMeal, String strMealThumb, String strInstructions) {
        this.idMeal = idMeal;
        this.strMeal = strMeal;
        this.strMealThumb = strMealThumb;
        this.strInstructions = strInstructions;
    }

    // Getter and Setter
    public String getIdMeal() {
        return idMeal;
    }

    public String getStrMeal() {
        return strMeal;
    }

    public String getStrMealThumb() {
        return strMealThumb;
    }

    public String getStrInstructions() {
        return strInstructions;
    }
}
