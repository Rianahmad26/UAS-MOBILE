package com.example.resepmasakan;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ResepAdapter extends RecyclerView.Adapter<ResepAdapter.ResepViewHolder> {

    private ArrayList<ModelResep> resepList;
    private Context context;

    public ResepAdapter(ArrayList<ModelResep> resepList, Context context) {
        this.resepList = resepList;
        this.context = context;
    }

    @Override
    public ResepViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_resep, parent, false);
        return new ResepViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ResepViewHolder holder, int position) {
        ModelResep resep = resepList.get(position);
        holder.txtTitle.setText(resep.getStrMeal());
        Glide.with(context).load(resep.getStrMealThumb()).into(holder.imgRecipe);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetailActivity.class);
            intent.putExtra("title", resep.getStrMeal());
            intent.putExtra("instructions", resep.getStrInstructions());
            intent.putExtra("imageUrl", resep.getStrMealThumb());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return resepList.size();
    }

    public static class ResepViewHolder extends RecyclerView.ViewHolder {

        TextView txtTitle;
        ImageView imgRecipe;

        public ResepViewHolder(View itemView) {
            super(itemView);
            txtTitle = itemView.findViewById(R.id.txtTitle);
            imgRecipe = itemView.findViewById(R.id.imgRecipe);
        }
    }
}
